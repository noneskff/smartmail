const message = document.getElementById('message');
const result = document.getElementById('result');
const check = document.getElementById('check');
const historyBox = document.getElementById('history');

async function loadHistory() {
  try {
    const response = await fetch('/api/history');
    if (!response.ok) throw new Error('History unavailable');
    const data = await response.json();
    ['total', 'spam', 'safe'].forEach(key => document.getElementById(key).textContent = data[key]);
    historyBox.replaceChildren();
    if (!data.history.length) { historyBox.textContent = 'No checks yet.'; return; }
    data.history.forEach(item => {
      const row = document.createElement('div'); row.className = 'entry';
      const preview = document.createElement('p'); preview.textContent = item.message.slice(0, 100);
      const label = document.createElement('strong'); label.textContent = item.result;
      label.className = item.result === 'Spam' ? 'spam' : 'safe';
      row.append(preview, label); historyBox.append(row);
    });
  } catch { historyBox.textContent = 'Could not load history.'; }
}

check.addEventListener('click', async () => {
  const text = message.value.trim();
  if (!text) { result.hidden = false; result.className = 'result error'; result.textContent = 'Please enter a message.'; return; }
  check.disabled = true; check.textContent = 'Checking...';
  try {
    const response = await fetch('/api/predict', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({message:text})});
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Prediction failed');
    result.hidden = false;
    result.className = 'result ' + (data.result === 'Spam' ? 'spam' : 'safe');
    result.textContent = `${data.result} — ${data.notice}`;
    await loadHistory();
  } catch (error) { result.hidden = false; result.className = 'result error'; result.textContent = error.message; }
  finally { check.disabled = false; check.textContent = 'Check Message'; }
});
document.getElementById('clear').addEventListener('click', () => {message.value='';result.hidden=true;message.focus();});
loadHistory();
